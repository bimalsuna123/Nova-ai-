package com.novaai.creative;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.util.Base64;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NovaBridge(), "NovaAI");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class NovaBridge {
        @JavascriptInterface
        public void generateImage(String prompt, String token) {
            executor.execute(() -> {
                HttpURLConnection connection = null;
                try {
                    if (token == null || token.trim().isEmpty()) {
                        sendError("Hugging Face access token daalein.");
                        return;
                    }
                    if (prompt == null || prompt.trim().isEmpty()) {
                        sendError("Pehle image prompt likhein.");
                        return;
                    }
                    URL url = new URL("https://router.huggingface.co/hf-inference/models/black-forest-labs/FLUX.1-schnell");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(30000);
                    connection.setReadTimeout(120000);
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Authorization", "Bearer " + token.trim());
                    connection.setRequestProperty("Content-Type", "application/json");
                    JSONObject body = new JSONObject();
                    body.put("inputs", prompt.trim());
                    byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
                    try (OutputStream out = connection.getOutputStream()) { out.write(payload); }
                    int code = connection.getResponseCode();
                    InputStream stream = (code >= 200 && code < 300)
                        ? connection.getInputStream() : connection.getErrorStream();
                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                    byte[] chunk = new byte[8192];
                    int count;
                    while ((count = stream.read(chunk)) != -1) buffer.write(chunk, 0, count);
                    byte[] response = buffer.toByteArray();
                    if (code >= 200 && code < 300) {
                        String image = Base64.encodeToString(response, Base64.NO_WRAP);
                        runJs("window.onNovaImage('data:image/png;base64," + image + "')");
                    } else {
                        String error = new String(response, StandardCharsets.UTF_8);
                        error = error.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
                        sendError("API error (" + code + "): " + error);
                    }
                } catch (Exception e) {
                    String error = e.getMessage() == null ? "Network error" : e.getMessage();
                    error = error.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
                    sendError(error);
                } finally {
                    if (connection != null) connection.disconnect();
                }
            });
        }

        private void sendError(String message) {
            String safe = message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
            runJs("window.onNovaError('" + safe + "')");
        }

        private void runJs(String script) {
            runOnUiThread(() -> webView.evaluateJavascript(script, null));
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        executor.shutdownNow();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
